-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.35 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table kyle.failed_jobs: ~0 rows (approximately)

-- Dumping data for table kyle.migrations: ~5 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2023_12_13_094319_create_works_table', 1);

-- Dumping data for table kyle.password_reset_tokens: ~0 rows (approximately)

-- Dumping data for table kyle.personal_access_tokens: ~0 rows (approximately)

-- Dumping data for table kyle.users: ~1 rows (approximately)
INSERT INTO `users` (`id`, `name`, `profile_name`, `email`, `email_verified_at`, `password`, `image`, `about`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'TechForge Solutions', 'TechForge Solutions', 'TechForge Solutions@gmail.com', '2023-12-20 07:00:18', '1234', 'http://127.0.0.1:8000/assets/1703073390.gif', 'Welcome to TechForge Solutions, your gateway to unparalleled digital innovation. At TechForge, we specialize in the seamless integration of technology and creativity to craft exceptional websites and cutting-edge software solutions. Our mission is to empower businesses with transformative digital experiences that not only meet but exceed their objectives.', NULL, NULL, '2023-12-20 03:56:30');

-- Dumping data for table kyle.works: ~6 rows (approximately)
INSERT INTO `works` (`id`, `image_path`, `created_at`, `updated_at`) VALUES
	(6, 'http://127.0.0.1:8000/assets/1703076310.png', '2023-12-20 04:45:10', '2023-12-20 04:45:10'),
	(7, 'http://127.0.0.1:8000/assets/1703076314.png', '2023-12-20 04:45:14', '2023-12-20 04:45:14'),
	(8, 'http://127.0.0.1:8000/assets/1703076320.png', '2023-12-20 04:45:20', '2023-12-20 04:45:20'),
	(9, 'http://127.0.0.1:8000/assets/1703076421.png', '2023-12-20 04:47:01', '2023-12-20 04:47:01'),
	(10, 'http://127.0.0.1:8000/assets/1703076982.png', '2023-12-20 04:56:22', '2023-12-20 04:56:22'),
	(11, 'http://127.0.0.1:8000/assets/1703076986.png', '2023-12-20 04:56:26', '2023-12-20 04:56:26');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
